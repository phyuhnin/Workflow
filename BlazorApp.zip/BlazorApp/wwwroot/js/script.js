﻿window.initScrollListener = (element, dotNetHelper) => {
    element.addEventListener("scroll", () => {
        if (element.scrollTop + element.clientHeight >= element.scrollHeight - 50) {
            dotNetHelper.invokeMethodAsync("OnScrollNearBottom");
        }
    });
}; 

//検索結果があればアコーディオンを自動的に閉じる
window.closeAccordion = function (accordionId) {
    var myCollapse = document.getElementById(accordionId);
    if (myCollapse && bootstrap) {
        var bsCollapse = bootstrap.Collapse.getInstance(myCollapse);
        if (!bsCollapse) {
            bsCollapse = new bootstrap.Collapse(myCollapse, { toggle: false });
        }
        bsCollapse.hide();
    }
};

//部品エリアからのフォームビルダーエリアへのドラック＆ドロップによる追加
window.setupDragula = (sourceId, targetId, dotNetHelper) => {
    const source = document.getElementById(sourceId);
    const target = document.getElementById(targetId);

    const drake = dragula([source, target], {
        copy: (el, src) => src === source,
        accepts: (el, target) => target.id === targetId,
        moves: (el, source, handle, sibling) => {
            // source-buttons内のボタンのみドラッグ可能
            return source.id === sourceId;
        }
    });

    drake.on('drop', function (el, target, source, sibling) {
        const type = el.getAttribute("data-type");

        if (type && target != null) {
            // sibling の前に入れる → その sibling の index を取得
            let index = 0;
            if (sibling) {
                index = Array.from(target.children).indexOf(sibling)-1;
            } else {
                index = target.children.length;
            }
            dotNetHelper.invokeMethodAsync("HandleDropWithIndex", type, index);
            el.remove(); // 仮DOMを削除
        }
    });
};

window.initializeDateTimePickers = function (dotNetRef) {
    const pickers = [
        { id: '#datetimepicker1', format: 'YYYY/MM/DD' },
        { id: '#datetimepicker2', format: 'HH:mm' },
        { id: '#datetimepicker3', format: 'YYYY/MM/DD HH:mm' }
    ];

    pickers.forEach(picker => {
        const el = document.querySelector(picker.id);
        if (!el) return;

        $(picker.id).datetimepicker({
            format: picker.format,
            locale: 'ja',
            icons: {
                time: 'far fa-clock',
                date: 'far fa-calendar-alt',
                up: 'fas fa-arrow-up',
                down: 'fas fa-arrow-down',
            },
            buttons: {
                showClose: true,
            }
        });

        // 双方向バインド: JS → Blazor
        $(picker.id).on("change.datetimepicker", function (e) {
            if (e.date) {
                dotNetRef.invokeMethodAsync('UpdateDateTimeValueFromJs', e.date.format(picker.format));
            }
        });
    });
};

window.settingFormatChanged = function (select_input_format, select_setting_format, initial_value, dotNetRef) {
    if (select_input_format === "日付") {
        $('#datetimepicker1').datetimepicker({
            format: select_setting_format,
            locale: 'ja',
            icons: {
                time: 'far fa-clock',
                date: 'far fa-calendar-alt',
                up: 'fas fa-arrow-up',
                down: 'fas fa-arrow-down',
            },
            buttons: {
                showClose: true,
            }
        });
        if (initial_value) {
            const formatted = moment(initial_value).format(select_setting_format);
            dotNetRef.invokeMethodAsync('UpdateInitialValueFromJs', formatted);
        }
        // 双方向バインド: JS → Blazor
        $('#datetimepicker1').on("change.datetimepicker", function (e) {
            if (e.date) {
                dotNetRef.invokeMethodAsync('UpdateDateTimeValueFromJs', e.date.format(select_setting_format));
            }
        });
    
    }
    else if (select_input_format === "時刻") {
        $('#datetimepicker2').datetimepicker({
            format: select_setting_format,
            locale: 'ja',
            icons: {
                time: 'far fa-clock',
                date: 'far fa-calendar-alt',
                up: 'fas fa-arrow-up',
                down: 'fas fa-arrow-down',
            },
            buttons: {
                showClose: true,
            }
        });
        if (initial_value) {
            const formatted = moment(initial_value, select_setting_format).format(select_setting_format);
            dotNetRef.invokeMethodAsync('UpdateInitialValueFromJs', formatted);
        }
        // 双方向バインド: JS → Blazor
        $('#datetimepicker2').on("change.datetimepicker", function (e) {
            if (e.date) {
                dotNetRef.invokeMethodAsync('UpdateDateTimeValueFromJs', e.date.format(select_setting_format));
            }
        });
    }
    else if (select_input_format === "日時") {
        $('#datetimepicker3').datetimepicker({
            format: select_setting_format,
            locale: 'ja',
            icons: {
                time: 'far fa-clock',
                date: 'far fa-calendar-alt',
                up: 'fas fa-arrow-up',
                down: 'fas fa-arrow-down',
            },
            buttons: {
                showClose: true,
            }
        });
        if (initial_value) {
            const formatted = moment(initial_value).format(select_setting_format);
            dotNetRef.invokeMethodAsync('UpdateInitialValueFromJs', formatted);
        }
        // 双方向バインド: JS → Blazor
        $('#datetimepicker3').on("change.datetimepicker", function (e) {
            if (e.date) {
                dotNetRef.invokeMethodAsync('UpdateDateTimeValueFromJs', e.date.format(select_setting_format));
            }
        });
    }
}

// BlazorからJS側に値を反映
window.setDatePickerValue = function (pickerId, value) {
    const el = document.querySelector(pickerId);
    if (el && $(pickerId).data("datetimepicker")) {
        $(pickerId).datetimepicker('date', moment(value, $(pickerId).data("datetimepicker").format));
    }
}
