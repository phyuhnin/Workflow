﻿namespace BlazorApp.Data
{
    public class FlowService
    {
        public Dictionary<string, string> GetHeader()
        {
            return new Dictionary<string, string>
            {
                { "flow_id", "フローID" },
                { "flow_name", "フロー名 " },
                { "flow_category", "分類 " },
                { "flow_version", "生成Ver" },
                { "status", "状態 " },
                { "service_start_date", "運用開始日 " },
                { "service_end_date", "運用終了日" },
                { "usage_permission", "利用許可" },
                { "allowed_group", "許可グループ" },
                { "application_flow_id_setting", "採番ルールID " },
            };
        }

        public List<Flow> GetFlows()
        {
            List<Flow> flows = new List<Flow>();
            for( int i = 0; i < 300; i++ )
            {
                flows.Add(new Flow { flow_id = (i + 1).ToString(), flow_name = "請求処理", flow_category = "業務", flow_version = "1.0", status = "有効", service_start_date = "2024-01-01", service_end_date = "2025-12-31", usage_permission = "全社", allowed_group = "経理部", application_flow_id_setting = "A001", application_flow_id_rule1 = "RuleA", application_flow_id_rule2 = "RuleB", application_flow_id_rule3 = "RuleC", application_flow_id_rule4 = "RuleD", application_flow_id_rule5 = "RuleE", application_flow_id = "AppFlow-001", fixed_value = "2024-FLOW", year_month = "2024-04", serial_number = "0001", naming_rules_setting = "NR001", naming_rule1 = "年月", naming_rule2 = "カテゴリ", naming_rule3 = "番号", naming_rule4 = "固定値", naming_rule5 = "バージョン", naming_rule = "年月-カテゴリ-番号" });

            }
            return flows;
        }

        public async Task InsertFlowAsync(Flow flow)
        {
            var query = @"
                CREATE (f:Flow {
                    flow_id: $flow_id,
                    flow_name: $flow_name,
                    flow_category: $flow_category,
                    flow_version: $flow_version,
                    status: $status,
                    service_start_date: $service_start_date,
                    service_end_date: $service_end_date,
                    usage_permission: $usage_permission,
                    allowed_group: $allowed_group,
                    application_flow_id_setting: $application_flow_id_setting,
                    application_flow_id_rule1: $application_flow_id_rule1,
                    application_flow_id_rule2: $application_flow_id_rule2,
                    application_flow_id_rule3: $application_flow_id_rule3,
                    application_flow_id_rule4: $application_flow_id_rule4,
                    application_flow_id_rule5: $application_flow_id_rule5,
                    application_flow_id: $application_flow_id,
                    fixed_value: $fixed_value,
                    year_month: $year_month,
                    serial_number: $serial_number,
                    naming_rules_setting: $naming_rules_setting,
                    naming_rule1: $naming_rule1,
                    naming_rule2: $naming_rule2,
                    naming_rule3: $naming_rule3,
                    naming_rule4: $naming_rule4,
                    naming_rule5: $naming_rule5,
                    naming_rule: $naming_rule
                })";

            //var session = _driver.AsyncSession();

            try
            {
                //await session.RunAsync(query, new
                //{
                //    flow.flow_id,
                //    flow.flow_name,
                //    flow.flow_category,
                //    flow.flow_version,
                //    flow.status,
                //    flow.service_start_date,
                //    flow.service_end_date,
                //    flow.usage_permission,
                //    flow.allowed_group,
                //    flow.application_flow_id_setting,
                //    flow.application_flow_id_rule1,
                //    flow.application_flow_id_rule2,
                //    flow.application_flow_id_rule3,
                //    flow.application_flow_id_rule4,
                //    flow.application_flow_id_rule5,
                //    flow.application_flow_id,
                //    flow.fixed_value,
                //    flow.year_month,
                //    flow.serial_number,
                //    flow.naming_rules_setting,
                //    flow.naming_rule1,
                //    flow.naming_rule2,
                //    flow.naming_rule3,
                //    flow.naming_rule4,
                //    flow.naming_rule5,
                //    flow.naming_rule
                //});
            }
            finally
            {
                //await session.CloseAsync();
            }
        }

        //public string FlowConditionSetting()
        //{
        //    var flowConditionSettingList = new List<FlowConditionSetting>
        //    {
        //        new FlowConditionSetting
        //        {
        //            logical_item_no = "1",
        //            logical_disjunction = "",
        //            logical_item_type = "Type1",
        //            logical_value1 =  "10",
        //            logical_operator = ">",
        //            logical_value2 = "5",
        //            next_node_id = "A001"
        //        },
        //        new FlowConditionSetting
        //        {
        //            logical_item_no = "2",
        //            logical_disjunction = "OR",
        //            logical_item_type = "Type2",
        //            logical_value1 =  "5",
        //            logical_operator = "<",
        //            logical_value2 = "10",
        //            next_node_id = "A001"
        //        },
        //        new FlowConditionSetting
        //        {
        //            logical_item_no = "2",
        //            logical_disjunction = "OR",
        //            logical_item_type = "Type3",
        //            logical_value1 =  "A001",
        //            logical_operator = "==",
        //            logical_value2 = "A001",
        //            next_node_id = "A001"
        //        },
        //        new FlowConditionSetting
        //        {
        //            logical_item_no = "2",
        //            logical_disjunction = "OR",
        //            logical_item_type = "Type3",
        //            logical_value1 =  "A001",
        //            logical_operator = "==",
        //            logical_value2 = "A001",
        //            next_node_id = "A001"
        //        },
        //        new FlowConditionSetting
        //        {
        //            logical_item_no = "3",
        //            logical_disjunction = "OR",
        //            logical_item_type = "Type3",
        //            logical_value1 =  "A002",
        //            logical_operator = "==",
        //            logical_value2 = "A001",
        //            next_node_id = "A001"
        //        },
        //        new FlowConditionSetting
        //        {
        //            logical_item_no = "3",
        //            logical_disjunction = "AND",
        //            logical_item_type = "Type3",
        //            logical_value1 =  "A002",
        //            logical_operator = "==",
        //            logical_value2 = "A001",
        //            next_node_id = "A001"
        //        }
        //    };
        //    string groupExpression = BuildConditionExpression(flowConditionSettingList);
        //    return groupExpression;
        //}

        //public string BuildConditionExpression(List<FlowConditionSetting> conditionList)
        //{
        //    var conditionExpression = "";
        //    var grouped = conditionList.GroupBy(c => c.logical_item_no);
        //    var groupExpressions = new List<string>();

        //    foreach( var group in grouped )
        //    {
        //        var expressions = new List<string>();

        //        foreach( var item in group )
        //        {

        //            //string left = GetLeftOperand(item);
        //            //string right = GetRightOperand(item);
        //            //string left = item.logical_value1;
        //            //string right = item.logical_value2;

        //            //string expr = $"{left} {item.logical_operator} {right}";
        //            //expressions.Add(expr);

        //            //int index;
        //            //for( int i = 0; i < myList.Count; i++ )
        //            //{
        //            //    if( myList[ i ].Prop == oProp )
        //            //    {
        //            //        index = i;
        //            //        break;
        //            //    }
        //            //}
        //            //for( int i = 0; i < item.Count; i++ )
        //            //{
        //            //    var item = items[ i ];
        //            //    string left = GetLeftOperand(item);
        //            //    string right = GetRightOperand(item);
        //            //    string expr = $"{left} {item.LogicalOperator} {right}";

        //            //    if( i > 0 )
        //            //    {
        //            //        string conj = string.IsNullOrWhiteSpace(item.LogicalDisjunction) ? "AND" : item.LogicalDisjunction;
        //            //        sb.Append($" {conj} ");
        //            //    }
        //            //}

        //            // 各グループ内の条件を OR や AND で連結
        //            var joined = string.Join(" OR ", expressions);
        //            groupExpressions.Add($"({joined})");
        //        }
        //        // グループ同士を OR でつなげる（必要なら別ルールにも変更可能）
        //        conditionExpression = string.Join(" OR ", groupExpressions);

        //    }
        //    return conditionExpression;
        //}

        //public class ConditionBuilder
        //{
        //    public string BuildConditionExpression(List<FlowConditionSetting> conditionList)
        //    {
        //        var grouped = conditionList.GroupBy(c => c.LogicalItemNo);
        //        var groupExpressions = new List<string>();

        //        foreach( var group in grouped )
        //        {
        //            var expressions = new List<string>();
        //            foreach( var item in group )
        //            {
        //                string left = GetLeftOperand(item);
        //                string right = GetRightOperand(item);
        //                string expr = $"{left} {item.LogicalOperator} {right}";

        //                expressions.Add(expr);
        //            }

        //            // Disjunction付きで連結
        //            var items = group.ToList();
        //            var groupExpr = items[ 0 ]; // 最初の条件

        //            string combined = GetExpressionWithDisjunction(items);

        //            groupExpressions.Add($"({combined})");
        //        }

        //        return string.Join(" OR ", groupExpressions); // グループ間は OR で結合（必要に応じて変更可）
        //    }

        //    private string GetExpressionWithDisjunction(List<FlowConditionSetting> items)
        //    {
        //        var sb = new System.Text.StringBuilder();

        //        for( int i = 0; i < items.Count; i++ )
        //        {
        //            var item = items[ i ];
        //            string left = GetLeftOperand(item);
        //            string right = GetRightOperand(item);
        //            string expr = $"{left} {item.LogicalOperator} {right}";

        //            if( i > 0 )
        //            {
        //                string conj = string.IsNullOrWhiteSpace(item.LogicalDisjunction) ? "AND" : item.LogicalDisjunction;
        //                sb.Append($" {conj} ");
        //            }

        //            sb.Append(expr);
        //        }

        //        return sb.ToString();
        //    }

        //    private string GetLeftOperand(FlowConditionSetting item)
        //    {
        //        return item.LogicalValue;
        //    }

        //    private string GetRightOperand(FlowConditionSetting item)
        //    {
        //        if( item.LogicalOperator == "=" || item.LogicalOperator == "!=" )
        //            return $"\"{item.next_node_id}\"";
        //        return item.next_node_id;
        //    }
        //}
    }
}




