﻿namespace BlazorApp.Data
{
    public class LinkItem
    {
        public string? url { get; set; }
        public string? display_text { get; set; }
    }
}
