﻿namespace BlazorApp.Data
{
    public class InputComponentService
    {
        private List<Dictionary<string, object>> _inputData = new();

        public void SetInputData(List<Dictionary<string, object>> data)
        {
            _inputData = data;
        }

        public List<Dictionary<string, object>> GetInputData()
        {
            return _inputData;
        }
    }
}
