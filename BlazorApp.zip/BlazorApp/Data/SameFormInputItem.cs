﻿namespace BlazorApp.Data
{
    public class SameFormInputItem
    {
        public string? select_reference_item { get; set; }
        public List<string> reference_item { get; set; } = new();
        public string? select_reference_input_condition { get; set; }
        public List<string> reference_input_condition { get; set; } = new();
        public string? reference_input_value { get; set; }
        public string? select_is_edit { get; set; }
        public List<string> is_edit { get; set; } = new List<string>()
        {
            "編集可","編集不可"
        };
        public string? select_display_item_type { get; set; }
        public List<string> display_item_type { get; set; } = new List<string>()
        {
            "テキスト","ドロップダウン","ボタン"
        };
    }
}
