﻿namespace BlazorApp.Data
{
    public class FlowApprovalClient
    {
        public string? approval_id { get; set; }
        public string? approval_step { get; set; }
        public string? approval_type { get; set; }
        public string? approval_title { get; set; }
        public string? user_id { get; set; }
        public string? group_id { get; set; }
        public string? group_level_from { get; set; }
        public string? group_level_to { get; set; }
        public string? approval_position { get; set; }
        public string? template_field { get; set; }
        public string? attach_file_flag { get; set; }
        public string? delication_flag { get; set; }
        public string? substitute_flag { get; set; }
        public string? substitute_user_id { get; set; }
        public string? substitute_group_id { get; set; }
        public string? substitute_user_position_from { get; set; }
        public string? substitute_user_position_to { get; set; }
        public string? send_back_flag { get; set; }
        public string? send_back_type { get; set; }
        public string? send_back_step { get; set; }
        public string? send_back_noti_flag { get; set; }
        public string? send_back_noti_type { get; set; }
        public string? deny_flag { get; set; }
    }
}
