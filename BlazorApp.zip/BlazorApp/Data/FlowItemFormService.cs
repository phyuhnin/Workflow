﻿namespace BlazorApp.Data
{
    public class FlowItemFormService
    {

        public Dictionary<string, string> GetHeader()
        {
            return new Dictionary<string, string>
            {
                { "form_category", "分類" },
                { "form_id", "帳票ID" },
                { "form_name", "帳票名 " },
                { "status", "状態 " },
                { "allowed_update", "変更可否" },
                { "updated_datetime", "最終更新日時 " },
                { "updated_user", "最終更新者 " },
                { "form_version", "バージョン" },
            };
        }

        public List<FlowItemForm> GetFlowItemForms()
        {
            List<FlowItemForm> flowItemForms = new List<FlowItemForm>();
            for( int i = 0; i < 300; i++ )
            {
                flowItemForms.Add(new FlowItemForm
                {
                    form_category = "分類A",
                    form_id = (i + 1).ToString(),
                    form_name = "請求処理",
                    status = "作成中",
                    allowed_update = "可",
                    updated_datetime = "2025/04/17 12:34",
                    updated_user = "田中太郎",
                    form_version = "v1.0",
                });

            }
            return flowItemForms;
        }
    }
}
