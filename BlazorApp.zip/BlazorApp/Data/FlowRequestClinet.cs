﻿namespace BlazorApp.Data
{
    public class FlowRequestClient
    {
        public string? user { get; set; }
        public string? attach_file_flag { get; set; }
        public string? template_copy_flag { get; set; }
        public string? multi_approve_flag { get; set; }
        public string? delication_flag { get; set; }
        public string? substitute_flag { get; set; }
        public string? substitute_user_id { get; set; }
        public string? substitute_group_id { get; set; }
        public string? substitute_user_position_from { get; set; }
        public string? substitute_user_position_to { get; set; }

        public List<FlowConditionSetting> FlowConditionSettings = new List<FlowConditionSetting>();
    }
}
