﻿namespace BlazorApp.Data
{
    public class GroupInputItem
    {
    }
}
